/**
 * 
 */
/**
 * @author cyber
 *
 */
module RunTrackerv3 {
	requires java.sql;
	requires java.desktop;
}