package runTrackerv3;

import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class displaySecondWindow extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					displaySecondWindow frame = new displaySecondWindow("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn = null;

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public displaySecondWindow(String userID) throws ClassNotFoundException, SQLException {
		PacePerfect pp = new PacePerfect();
		pp.connectDB();
		pp.loadData();
		pp.clients.get(0).getUser();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 646, 437);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JFormattedTextField weightTF = new JFormattedTextField();
		weightTF.setBounds(21, 356, 128, 26);
		contentPane.add(weightTF);
		
		JFormattedTextField distTF = new JFormattedTextField();
		distTF.setBounds(21, 128, 87, 23);
		contentPane.add(distTF);
		
		JFormattedTextField timeTF = new JFormattedTextField();
		timeTF.setBounds(118, 128, 128, 23);
		contentPane.add(timeTF);
		
		JFormattedTextField dateTF = new JFormattedTextField();
		dateTF.setBounds(256, 128, 128, 23);
		contentPane.add(dateTF);
		
		JRadioButton runRB = new JRadioButton("Add a run!");
		runRB.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try {
					float distance = Float.parseFloat(distTF.getText());
					float time = Float.parseFloat(timeTF.getText());
					String runDate = dateTF.getText();
					JOptionPane.showMessageDialog(null, pp.Entry2(userID, distance, time, runDate));
				} catch (HeadlessException | IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		runRB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		runRB.setBounds(21, 81, 109, 23);
		contentPane.add(runRB);
		
		JRadioButton progressRB = new JRadioButton("See your progress!");
		progressRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					JOptionPane.showMessageDialog(null, pp.CaloriesBurnt2(userID));
					
				} catch (HeadlessException | IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		progressRB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		progressRB.setBounds(21, 159, 148, 23);
		contentPane.add(progressRB);
		
		JRadioButton historyRB = new JRadioButton("Check your running history!");
		historyRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JOptionPane.showMessageDialog(null, pp.ViewRuns2(userID));
				} catch (HeadlessException | IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		historyRB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		historyRB.setBounds(21, 206, 225, 23);
		contentPane.add(historyRB);
		
		JRadioButton recRB = new JRadioButton("Get your recommendations for the week");
		recRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JOptionPane.showMessageDialog(null, pp.generateWeeklyRecommendations2(userID));
				} catch (HeadlessException | IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		recRB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		recRB.setBounds(21, 258, 279, 23);
		contentPane.add(recRB);
		
		JRadioButton weightRB = new JRadioButton("Change weight.");
		weightRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int weight = Integer.parseInt(weightTF.getText());
					JOptionPane.showMessageDialog(null, pp.changeWeight2(userID, weight));
				} catch (HeadlessException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			
				}
			});
		
		
		weightRB.setFont(new Font("Tahoma", Font.PLAIN, 14));
		weightRB.setBounds(21, 309, 128, 23);
		contentPane.add(weightRB);
		
		ButtonGroup G = new ButtonGroup();
		G.add(weightRB);
		G.add(recRB);
		G.add(historyRB);
		G.add(progressRB);
		G.add(runRB);
		
		JLabel lblNewLabel = new JLabel("Menu:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
		lblNewLabel.setBounds(21, 23, 109, 53);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Distance (miles)");
		lblNewLabel_1.setBounds(21, 110, 87, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Time taken (hours)");
		lblNewLabel_2.setBounds(118, 110, 109, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Date (MM/DD/YYYY)");
		lblNewLabel_3.setBounds(256, 110, 128, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New Weight:");
		lblNewLabel_4.setBounds(21, 341, 87, 16);
		contentPane.add(lblNewLabel_4);
	}
}
	
