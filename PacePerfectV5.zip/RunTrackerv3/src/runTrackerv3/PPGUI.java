package runTrackerv3;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.io.IOException;
import javax.swing.JFormattedTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JPasswordField;


public class PPGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	PacePerfect pp = new PacePerfect();
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PPGUI window = new PPGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	Connection conn = null;
	private JPasswordField passwordField;

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public PPGUI() throws ClassNotFoundException, SQLException {
		
		initialize();
		
		conn = dbConnection.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	private void initialize() throws ClassNotFoundException, SQLException {
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JFormattedTextField userIDField = new JFormattedTextField();
		userIDField.setBounds(98, 85, 132, 20);
		frame.getContentPane().add(userIDField);
		
		
		
		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	                try {
	                	String query = "SELECT * FROM HASH WHERE username=? and password=?";
	                    PreparedStatement pst = conn.prepareStatement(query);
	                    String userID = userIDField.getText();
	                    pst.setString(1, userID);
	                    pst.setString(2, passwordField.getText());
	                    
	                    
	                    
	                    ResultSet rs = pst.executeQuery();
	                    int count = 0;
	                    while(rs.next()) {
	                    	count++;
	                    }
	                    if(count == 1) {
	                    	JOptionPane.showMessageDialog(null, "Username and password are correct.");
	                    	frame.dispose();
	                    	displaySecondWindow second = new displaySecondWindow(userID);
	                    	second.setVisible(true);
	                    }
	                    else if (count >1) {
	                    	JOptionPane.showMessageDialog(null, "Duplicate Username and password");
	                    }
	                    else {
	                    	JOptionPane.showMessageDialog(null, "Username and password are not correct.");
	                    }
	                    
	                    rs.close();
	                    pst.close();
	                } catch (SQLException e1) {
	                    e1.printStackTrace();
	                } catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	                }
			
		});
		loginButton.setBounds(70, 190, 89, 23);
		frame.getContentPane().add(loginButton);
		
		JLabel lblNewLabel = new JLabel("User ID:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 86, 78, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPassword.setBounds(10, 134, 78, 14);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to Pace Perfect!");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(10, 31, 359, 43);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel imageLabel = new JLabel("");
		Image image = new ImageIcon(this.getClass().getResource("/pacepr.jpg")).getImage();
		Image newImage = image.getScaledInstance(168, 175, Image.SCALE_DEFAULT);
		imageLabel.setIcon(new ImageIcon(newImage));
		imageLabel.setBounds(242, 38, 169, 175);
		frame.getContentPane().add(imageLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(98, 133, 132, 20);
		frame.getContentPane().add(passwordField);
		
	}
	
	public String userID(String id) {
		String userID = id;
		return userID;
		
	}
}
