package runTrackerv3;

import java.io.IOException;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class RunHistory {

	private String runID;
	private String userID;
	private float distance;
	private float time;
	private String runDate;
	private float pace;

	public RunHistory(String runID, String userID, float distance, float time, String runDate, float pace) {
		this.runID = runID;
		this.userID = userID;
		this.distance = distance;
		this.time = time;
		this.runDate = runDate;
		this.pace = pace;
	}

	public RunHistory() {
		this.runID = "";
		this.userID = "";
		this.distance = 0;
		this.time = 0;
		this.runDate = null;
		this.pace = 0;
	}

	public String getRunID() {
		return runID;
	}

	public void setRunID(String runID) {
		this.runID = runID;
	}

	public String getUser() {
		return userID;
	}

	public void setUser(String userID) {
		this.userID = userID;
	}

	public float getDistance() {
		return distance;
	}

	public void setDistance(float distance) {
		this.distance = distance;
	}

	public float getTime() {
		return time;
	}

	public void setTime(float time) {
		this.time = time;
	}

	public String getRunDate() {
		return runDate;
	}

	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}

	public float getPace() {
		return pace;
	}

	public void setPace(float pace) {
		this.pace = pace;
	}

	// Rest of the methods, including getMets(), toString(), etc.

	public double getMets() {
	    // Format the pace value to match the format in the paceToMets map
	    String formattedPace = String.format("%.1f", pace);

	    // Create a mapping of formatted pace values to METs
	    Map<String, Double> paceToMets = new HashMap<>();
	    paceToMets.put("5.0", 6.0);
	    paceToMets.put("6.0", 8.0);
	    paceToMets.put("7.0", 10.0);
	    paceToMets.put("8.0", 11.5);
	    paceToMets.put("9.0", 12.8);

	    // Find the corresponding MET value for the formatted pace
	    double metValue = paceToMets.getOrDefault(formattedPace, 0.0);

	    // If the pace is not an exact match, find the lower bound MET value
	    if (metValue == 0.0) {
	        Double lowerBoundMets = null;
	        for (Map.Entry<String, Double> entry : paceToMets.entrySet()) {
	            double paceValue = Double.parseDouble(entry.getKey());
	            if (paceValue <= pace) {
	                lowerBoundMets = entry.getValue();
	            } else {
	                break; // Stop searching when the current pace is greater than the target pace
	            }
	        }

	        if (lowerBoundMets != null) {
	            metValue = lowerBoundMets;
	        }
	    }

	    return metValue;
	}



	@Override
	public String toString() {
	    return "RunID: " + runID + " UserID: " + userID + " Distance traveled: " + String.format("%.2f", distance)
	            + " Time spent running: " + time + " Pace: " + String.format("%.2f", pace) + " Date: " + runDate + "\n";
	}

}
